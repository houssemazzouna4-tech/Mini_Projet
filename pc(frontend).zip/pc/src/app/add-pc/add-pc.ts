import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { PC } from '../model/pc.model';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-add-pc',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-pc.html',
  styleUrl: './add-pc.css'
})
export class AddPc implements OnInit {
  newPc = new PC();
  types: TypePc[] = [];
  newIdType: number | undefined = 1;
  newType?: TypePc;

  constructor(
    private pcService: PcService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.pcService.listeTypes().subscribe(ts => {
      console.log(ts);
      this.types = ts._embedded.types;
      if (this.types.length > 0 && !this.types.some(t => t.idType == this.newIdType)) {
        this.newIdType = this.types[0].idType;
      }
    });
  }

  addPc(): void {
    this.newType = this.types.find(t => t.idType == this.newIdType);
    this.newPc.type = this.newType ?? null;
    if (this.newPc.dateCreation) {
      this.newPc.dateCreation = new Date(this.newPc.dateCreation);
    }

    this.pcService.ajouterPc(this.newPc).subscribe(() => {
      this.router.navigate(['/pcs']);
    });
  }
}