import { TypePc } from './type.model';

export class TypeWrapper {
  _embedded!: { types: TypePc[] };
}