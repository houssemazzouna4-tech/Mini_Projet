import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PC } from '../model/pc.model';
import { TypePc } from '../model/type.model';
import { TypeWrapper } from '../model/TypeWrapped.model';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class PcService {
  apiURL: string = 'http://localhost:8080/pc/api';
  apiURLType: string = 'http://localhost:8080/pc/type';

  constructor(private http: HttpClient) { }

  listePcs(): Observable<PC[]> {
    return this.http.get<PC[]>(this.apiURL);
  }

  consulterPc(id: number): Observable<PC> {
    return this.http.get<PC>(`${this.apiURL}/${id}`);
  }

  ajouterPc(pc: PC): Observable<PC> {
    return this.http.post<PC>(this.apiURL, pc, httpOptions);
  }

  modifierPc(pc: PC): Observable<PC> {
    return this.http.put<PC>(this.apiURL, pc, httpOptions);
  }

  supprimerPc(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiURL}/${id}`);
  }

  consulterType(id: number): Observable<TypePc> {
    return this.http.get<TypePc>(`${this.apiURLType}/${id}`);
  }

  ajouterType(type: TypePc): Observable<TypePc> {
    return this.http.post<TypePc>(this.apiURLType, type, httpOptions);
  }

  modifierType(type: TypePc): Observable<TypePc> {
    return this.http.put<TypePc>(`${this.apiURLType}/${type.idType}`, type, httpOptions);
  }

  supprimerType(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiURLType}/${id}`);
  }
  listeTypes(): Observable<TypeWrapper> {
    return this.http.get<TypeWrapper>(this.apiURLType);
  }
}