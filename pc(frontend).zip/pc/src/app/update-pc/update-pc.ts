import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PC } from '../model/pc.model';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-update-pc',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './update-pc.html',
  styleUrl: './update-pc.css'
})
export class UpdatePc implements OnInit {
  private cdr = inject(ChangeDetectorRef);

  pcSelectionne!: PC;
  types: TypePc[] = [];
  updatedTypeId = 1;
  dateModification = '';

  constructor(
    private pcService: PcService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.pcService.listeTypes().subscribe({
      next: ts => {
        console.log(ts);
        this.types = ts._embedded?.types ?? [];
        this.cdr.detectChanges();
      },
      error: err => console.error('Erreur listeTypes:', err)
    });

    const id = Number(this.route.snapshot.paramMap.get('id'));

    this.pcService.consulterPc(id).subscribe({
      next: pc => {
        this.pcSelectionne = pc;
        this.updatedTypeId = this.pcSelectionne.type?.idType ?? this.types[0]?.idType ?? 1;

        if (this.pcSelectionne.dateCreation) {
          const date = new Date(this.pcSelectionne.dateCreation);
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, '0');
          const day = String(date.getDate()).padStart(2, '0');

          this.dateModification = `${year}-${month}-${day}`;
        }

        this.cdr.detectChanges();
      },
      error: () => {
        this.router.navigate(['/pcs']);
      }
    });
  }

  enregistrerModification(): void {
    if (this.pcSelectionne) {
      this.pcSelectionne.type = this.types.find(t => t.idType == this.updatedTypeId) ?? null;

      if (this.dateModification) {
        this.pcSelectionne.dateCreation = new Date(this.dateModification + 'T12:00:00');
      }

      this.pcService.modifierPc(this.pcSelectionne).subscribe(() => {
        this.router.navigate(['/pcs']);
      });
    }
  }
}