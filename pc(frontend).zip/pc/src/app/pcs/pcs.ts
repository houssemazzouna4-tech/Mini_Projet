import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { PC } from '../model/pc.model';
import { PcService } from '../services/pc';
import { AuthService } from '../services/auth';

@Component({
  selector: 'app-pcs',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './pcs.html',
  styleUrl: './pcs.css'
})
export class Pcs implements OnInit {

  auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);
  pcs: PC[] = [];

  constructor(private pcService: PcService) {}

  chargerPcs(): void {
    this.pcService.listePcs().subscribe({
      next: pcs => {
        console.log('PCS:', pcs);
        this.pcs = [...pcs];
        this.cdr.detectChanges();
      },
      error: err => console.error('Erreur listePcs:', err)
    });
  }

  ngOnInit(): void {
    this.chargerPcs();
  }

  supprimer(pc: PC): void {
    if (this.auth.isAdmin()) {
      if (confirm('Voulez-vous vraiment supprimer ce PC ?')) {
        if (pc.idPc != null) {
          this.pcService.supprimerPc(pc.idPc).subscribe(() => {
            this.chargerPcs();
          });
        }
      }
    }
  }
}