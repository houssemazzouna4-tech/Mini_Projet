import { Pipe, PipeTransform } from '@angular/core';
import { PC } from './model/pc.model';

@Pipe({
  name: 'searchFilter',
  standalone: true
})
export class SearchFilterPipe implements PipeTransform {
  transform(pcs: PC[] | null | undefined, searchTerm: string): PC[] {
    if (!pcs) return [];
    if (!searchTerm || !searchTerm.trim()) return pcs;

    const term = searchTerm.trim().toLowerCase();
    return pcs.filter(pc => pc.nomPc?.toLowerCase().includes(term) ?? false);
  }
}