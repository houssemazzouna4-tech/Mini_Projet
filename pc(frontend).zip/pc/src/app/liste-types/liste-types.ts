import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';
import { AuthService } from '../services/auth';
import { CommonModule } from '@angular/common';
import { UpdateType } from '../update-type/update-type';

@Component({
  selector: 'app-liste-types',
  standalone: true,
  imports: [CommonModule, UpdateType],
  templateUrl: './liste-types.html',
  styles: ``
})
export class ListeTypes implements OnInit {

  auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  types: TypePc[] = [];
  updatedType: TypePc = { idType: 0, nomType: '' };
  ajout: boolean = true;

  constructor(private pcService: PcService) {}

  ngOnInit(): void {
    this.chargerTypes();
  }

  typeUpdated(type: TypePc): void {
    if (!this.auth.isAdmin()) return;

    if (this.ajout) {
      const nouveauType = { nomType: type.nomType } as TypePc;
      this.pcService.ajouterType(nouveauType).subscribe({
        next: () => {
          this.updatedType = { idType: 0, nomType: '' };
          this.ajout = true;
          this.chargerTypes();
          this.cdr.detectChanges();
        },
        error: err => console.error('Erreur ajouterType:', err)
      });
    } else {
      this.pcService.modifierType(type).subscribe({
        next: () => {
          this.updatedType = { idType: 0, nomType: '' };
          this.ajout = true;
          this.chargerTypes();
          this.cdr.detectChanges();
        },
        error: err => console.error('Erreur modifierType:', err)
      });
    }
  }

  chargerTypes(): void {
    this.pcService.listeTypes().subscribe({
      next: ts => {
        this.types = [...(ts._embedded?.types ?? [])];
        this.cdr.detectChanges();
      },
      error: err => console.error('Erreur listeTypes:', err)
    });
  }

  updateType(type: TypePc): void {
    if (!this.auth.isAdmin()) return;
    this.updatedType = { ...type };
    this.ajout = false;
    this.cdr.detectChanges();
  }
}