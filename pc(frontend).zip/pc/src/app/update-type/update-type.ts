import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { TypePc } from '../model/type.model';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-type',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './update-type.html',
  styles: ``
})
export class UpdateType implements OnInit {

  @Input()
  type!: TypePc;

  @Output()
  typeUpdated = new EventEmitter<TypePc>();

  @Input()
  ajout!: boolean;

  ngOnInit(): void {
    console.log('ngOnInit du composant UpdateType', this.type);
  }

  saveType(): void {
    if (this.type?.nomType?.trim()) {
      this.typeUpdated.emit({ ...this.type });
    }
  }
}