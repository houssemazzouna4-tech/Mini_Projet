import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PC } from '../model/pc.model';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-recherche-type',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './recherche-type.html',
  styleUrl: './recherche-type.css'
})
export class RechercheParType implements OnInit {
  private cdr = inject(ChangeDetectorRef);

  pcs: PC[] = [];
  pcsFiltres: PC[] = [];
  types: TypePc[] = [];
  typeSelectionne: number | null = null;

  constructor(private pcService: PcService) {}

  ngOnInit(): void {
    this.pcService.listePcs().subscribe({
      next: pcs => {
        this.pcs = [...pcs];
        this.pcsFiltres = [...pcs];
        this.cdr.detectChanges();
      },
      error: err => console.error('Erreur listePcs:', err)
    });

    this.pcService.listeTypes().subscribe({
      next: ts => {
        this.types = [...(ts._embedded?.types ?? [])];
        this.cdr.detectChanges();
      },
      error: err => console.error('Erreur listeTypes:', err)
    });
  }

  rechercherParType(): void {
    if (this.typeSelectionne === null || this.typeSelectionne === undefined) {
      this.pcsFiltres = [...this.pcs];
    } else {
      this.pcsFiltres = this.pcs.filter(
        pc => pc.type?.idType == this.typeSelectionne
      );
    }
    this.cdr.detectChanges();
  }
}