package com.houssem.pc.entities;

import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Pc {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idPc;
	private String nomPc;
	private Double prixPc;
	private Date dateCreation;

	@ManyToOne
	private Type type;

	public Long getIdPc() {
		return idPc;
	}

	public void setIdPc(Long idPc) {
		this.idPc = idPc;
	}

	public String getNomPc() {
		return nomPc;
	}

	public void setNomPc(String nomPc) {
		this.nomPc = nomPc;
	}

	public Double getPrixPc() {
		return prixPc;
	}

	public void setPrixPc(Double prixPc) {
		this.prixPc = prixPc;
	}

	public Date getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Pc(String nomPc, Double prixPc, Date dateCreation) {
		super();
		this.nomPc = nomPc;
		this.prixPc = prixPc;
		this.dateCreation = dateCreation;
	}

	public Pc(String nomPc, Double prixPc, Date dateCreation, Type type) {
		super();
		this.nomPc = nomPc;
		this.prixPc = prixPc;
		this.dateCreation = dateCreation;
		this.type = type;
	}

	public Pc() {
		super();
	}

	@Override
	public String toString() {
		return "Pc [idPc=" + idPc + ", nomPc=" + nomPc + ", prixPc=" + prixPc + ", dateCreation=" + dateCreation+ ", type=" + type + "]";
	}
}