package com.houssem.pc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;

import com.houssem.pc.entities.Pc;
import com.houssem.pc.entities.Type;

@SpringBootApplication
public class PcApplication implements CommandLineRunner {

	private final RepositoryRestConfiguration repositoryRestConfiguration;

	PcApplication(RepositoryRestConfiguration repositoryRestConfiguration) {
		this.repositoryRestConfiguration = repositoryRestConfiguration;
	}

	public static void main(String[] args) {
		SpringApplication.run(PcApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		repositoryRestConfiguration.exposeIdsFor(Pc.class, Type.class);
	}
}