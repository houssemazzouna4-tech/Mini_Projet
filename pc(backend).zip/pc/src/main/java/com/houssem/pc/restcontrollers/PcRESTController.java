package com.houssem.pc.restcontrollers;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.houssem.pc.entities.Pc;
import com.houssem.pc.service.PcService;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/api")
@CrossOrigin
@AllArgsConstructor
public class PcRESTController {

	private final PcService pcService;

	@GetMapping
	public List<Pc> getAllPcs() {
		return pcService.getAllPcs();
	}

	@GetMapping("/{id}")
	public Pc getPcById(@PathVariable("id") Long id) {
		return pcService.getPc(id);
	}

	@PostMapping
	public Pc createPc(@RequestBody Pc pc) {
		return pcService.savePc(pc);
	}
	@PutMapping
	public Pc updatePc(@RequestBody Pc pc) {
		return pcService.updatePc(pc);
	}
	@DeleteMapping("/{id}")
	public void deletePc(@PathVariable("id") Long id) {
		pcService.deletePcById(id);
	}
	@GetMapping("/pctype/{idType}")
	public List<Pc> getPcsByTypeId(@PathVariable("idType") Long idType) {
		return pcService.findByTypeIdType(idType);
	}
}