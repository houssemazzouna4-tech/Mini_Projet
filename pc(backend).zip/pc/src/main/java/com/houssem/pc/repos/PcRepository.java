package com.houssem.pc.repos;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.houssem.pc.entities.Pc;
import com.houssem.pc.entities.Type;


@RepositoryRestResource(path = "rest")
public interface PcRepository extends JpaRepository<Pc, Long> {

	List<Pc> findByNomPc(String nom);
	List<Pc> findByNomPcContains(String nom);
	
	/*@Query("select p from Pc p where p.nomPc like %?1 and p.prixPc > ?2")
	List<Pc> findByNomPrix(String nom, Double prix);*/
	
	@Query("select p from Pc p where p.nomPc like %:nom and p.prixPc > :prix")
	List<Pc> findByNomPrix(@Param("nom") String nom, @Param("prix") Double prix);
	
	@Query("select p from Pc p where p.type = ?1")
	List<Pc> findByType(Type type);
	
	List<Pc> findByTypeIdType(Long id);

	List<Pc> findByOrderByNomPcAsc();
	@Query("select p from Pc p order by p.nomPc ASC, p.prixPc DESC")
	List<Pc> trierPcsNomsPrix();
}