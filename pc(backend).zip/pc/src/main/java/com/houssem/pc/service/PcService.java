package com.houssem.pc.service;

import java.util.List;
import com.houssem.pc.entities.Pc;
import com.houssem.pc.entities.Type;

public interface PcService {
	Pc savePc(Pc p);
	Pc updatePc(Pc p);
	void deletePc(Pc p);
	void deletePcById(Long id);
	Pc getPc(Long id);
	List<Pc> getAllPcs();
	List<Pc> findByNomPc(String nom);
	List<Pc> findByNomPcContains(String nom);
	List<Pc> findByNomPrix(String nom, Double prix);
	List<Pc> findByType(Type type);
	List<Pc> findByTypeIdType(Long id);
	List<Pc> findByOrderByNomPcAsc();
	List<Pc> trierPcsNomsPrix();
}