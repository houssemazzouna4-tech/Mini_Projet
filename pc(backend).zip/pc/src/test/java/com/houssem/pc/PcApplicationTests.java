package com.houssem.pc;

import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.houssem.pc.entities.Pc;
import com.houssem.pc.entities.Type;
import com.houssem.pc.repos.PcRepository;

@SpringBootTest
class PcApplicationTests {

	@Autowired
	private PcRepository pcRepository;

	@Test
	public void testCreatePc() {
		Pc prod = new Pc("PC Dell", 2200.500, new Date());
		pcRepository.save(prod);
	}

	@Test
	public void testFindPc() {
		Pc p = pcRepository.findById(1L).get();
		System.out.println(p);
	}

	@Test
	public void testUpdatePc() {
		Pc p = pcRepository.findById(1L).get();
		p.setPrixPc(1000.0);
		pcRepository.save(p);
	}

	@Test
	public void testDeletePc() {
		pcRepository.deleteById(1L);
	}

	@Test
	public void testListerTousPcs() {
		List<Pc> prods = pcRepository.findAll();
		for (Pc p : prods) {
			System.out.println(p);
		}
	}
	@Test
	public void testFindByNomPc() {
		List<Pc> pcs = pcRepository.findByNomPc("PC Dell");
		for (Pc p : pcs) {
			System.out.println(p);
		}
	}
	@Test
	public void testFindByNomPcContains() {
		List<Pc> pcs = pcRepository.findByNomPcContains("Dell");
		for (Pc p : pcs) {
			System.out.println(p);
		}
	}
	@Test
	public void testFindByNomPrix() {
		List<Pc> pcs = pcRepository.findByNomPrix("Dell", 1000.0);
		for (Pc p : pcs) {
			System.out.println(p);
		}
	}
	@Test
	public void testFindByType() {
		Type t = new Type();
		t.setIdType(1L);
		List<Pc> pcs = pcRepository.findByType(t);
		for (Pc p : pcs) {
			System.out.println(p);
		}
	}
	@Test
	public void testFindByTypeIdType() {
		List<Pc> pcs = pcRepository.findByTypeIdType(1L);
		for (Pc p : pcs) {
			System.out.println(p);
		}
	}
	@Test
	public void testFindByOrderByNomPcAsc() {
		List<Pc> pcs = pcRepository.findByOrderByNomPcAsc();
		for (Pc p : pcs) {
			System.out.println(p);
		}
	}
	@Test
	public void testTrierPcsNomsPrix() {
		List<Pc> pcs = pcRepository.trierPcsNomsPrix();
		for (Pc p : pcs) {
			System.out.println(p);
		}
	}
}